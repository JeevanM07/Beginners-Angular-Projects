export const imageConfig = {
    quality:0.2,
    width: 800,
    height: 600,
    autoRotate: true,
}