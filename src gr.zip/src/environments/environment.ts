// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyD3sD2WOOlnUk4kqSqomXGtEARtNytTzsY",
    authDomain: "paingram-9ef66.firebaseapp.com",
    projectId: "paingram-9ef66",
    storageBucket: "paingram-9ef66.appspot.com",
    messagingSenderId: "194408739723",
    appId: "1:194408739723:web:87596f30c194635fe3b58e"
  }
};



// firebaseConfig : {
  //   apiKey: "AIzaSyB1y7pq1_xCOgAE0aM_UnIS3EpI0lFBoAE",
  //   authDomain: "paingram-ed636.firebaseapp.com",
  //   projectId: "paingram-ed636",
  //   storageBucket: "paingram-ed636.appspot.com",
  //   messagingSenderId: "844095538748",
  //   appId: "1:844095538748:web:451a6176bb083718ea6539"
  // }

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
