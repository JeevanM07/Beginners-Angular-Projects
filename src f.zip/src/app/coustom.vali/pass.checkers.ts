import { FormGroup } from "@angular/forms"

export function passwordChecker(
    controlName: string, 
    compareControlName: string,
    )
    {
        return(formGroup : FormGroup) =>{
            const password = formGroup.controls[controlName];
            const confpassword = formGroup.controls[compareControlName];

            if(password.value != confpassword.value){

                confpassword.setErrors({ mustmatch: true });
            }else{
                confpassword.setErrors(null);
            }
        }

}